first_number = int(input("Enter the first number: "))
operation = input("Enter +, -, /, * or **: ")
second_number = int(input("Enter the second number: "))

try:
    operation = first_number / second_number
except ZeroDivisionError:
    print("Please, do not divide by O")

if operation == "+":
    print(first_number + second_number)
elif operation == "-":
    print(first_number - second_number)
elif operation == "/":
    print(first_number / second_number)
elif operation == "*":
    print(first_number * second_number)
elif operation == "**":
    print(first_number ** second_number)
else:
    print("error, please choose a valid operator")
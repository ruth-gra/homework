secret = "13"

guess = input("Please guess our secret number between 0 an 20: ")

if guess == secret:
    print("Congrats - You won!")
else:
    print("Give it another try!")
# Libraries importieren
import random
import json  # Dateiaustausch
import datetime

#Funktionen

def wrong_guess(new_guess):
    print("Your guess is not correct... try something", new_guess)

def play_game(name = ""):

    # Listen und Variablen definieren
    secret = random.randint(1, 13)
    attempts = 0
    score_list = {}
    wrong_guesses = []

    # Exception Handling einfügen --> verhindert, dass das Programm abbricht, wenn die Liste noch leer ist (bspw. noch niemand gespielt hat)
    try:

        with open("score_list.txt", "r") as scores:
            score_list = json.loads(scores.read())
            test = sorted(score_list, key=lambda top: top["attempts"])[:3]
            print("Top Scores: " + str(test))

    except Exception:
        print("Fehlermeldung")

        for score_dict in score_list:
            print(format(str(score_dict["attempts"]) + score_dict.get("date & time") + score_dict.get("name")))

    # Beginn des Spiels

    if not name:
        name = input("Please enter your name: ")

    while True:

        guess = int(input("Guess the secret number (between 1 and 13): "))
        attempts += 1

        if guess == secret:
            score_list.append(
                {
                    "attempts": attempts,
                    "date & time": str(datetime.datetime.now()),
                    "Name": name,
                    "wrong_guesses": wrong_guesses
                 }
            )

            with open("score_list.txt", "w") as scores:
                scores.write(json.dumps(score_list))

            print("Great Job! It's number " + str(secret))
            print("You needed: " + str(attempts) + " " "attempts")

            play_again(name)

        elif guess > secret:
            wrong_guess("smaller")
            wrong_guesses.append(guess)

        elif guess < secret:
            wrong_guess("bigger")
            wrong_guesses.append(guess)

def play_again(player):
    question = input("Do you want to play again, " + player + "?" + " Type y for yes an n for no: ")
    if question == "y":
        play_game(player)

    else:
        print("See you next time!")

play_game()




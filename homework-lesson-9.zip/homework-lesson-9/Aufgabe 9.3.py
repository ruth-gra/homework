string = "Today Is A BeautiFul DAY"

print(string.lower())